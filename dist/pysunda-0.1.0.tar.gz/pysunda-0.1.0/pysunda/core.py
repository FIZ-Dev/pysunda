# pysunda/core.py

def tulis(pesan):
    """Fungsi untuk mencetak pesan ke layar."""
    print(pesan)

def itung_panjang(data):
    """Fungsi untuk menghitung panjang data."""
    return len(data)

def tambihkeun(daptar, elemen):
    """Fungsi untuk menambahkan elemen ke dalam daptar."""
    daptar.append(elemen)

def susun(daptar):
    """Fungsi untuk menyusun daptar."""
    daptar.sort()

# Tambahkan lebih banyak fungsi sesuai kebutuhan...
